# 导入语言切换插件，确保它被注册
from ExamOnline.plugins.language_switch import LanguageSwitchPlugin