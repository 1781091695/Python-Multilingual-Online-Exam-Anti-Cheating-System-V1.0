from django.utils.translation import gettext_lazy as _
from django.conf import settings
from django.utils.translation import activate, get_language
import xadmin
from xadmin.views import BaseAdminPlugin, CommAdminView
from xadmin.layout import Main, TabHolder, Tab, Fieldset, Row, Col, AppendedText, Side
from xadmin.plugins.inline import Inline
from xadmin.plugins.batch import BatchChangeAction

class LanguageSwitchPlugin(BaseAdminPlugin):
    """语言切换插件"""
    # 插件名称
    language_switch = True
    
    def init_request(self, *args, **kwargs):
        # 启用插件
        return bool(self.language_switch)
    
    def block_top_navmenu(self, context, nodes):
        """在顶部导航栏添加语言切换下拉菜单"""
        # 获取当前语言
        current_language = get_language()
        
        # 获取当前语言的显示名称
        current_language_name = current_language
        for code, name in settings.LANGUAGES:
            if code == current_language:
                current_language_name = name
                break
        
        # 构建与当前HTML结构兼容的语言切换下拉菜单
        # 使用id="g-setlang-menu"的ul元素，确保与现有HTML结构匹配
        language_html = '<li class="dropdown g-setlang">'
        language_html += '<a class="dropdown-toggle" role="button" data-toggle="dropdown" href="#">'
        language_html += '<i class="fa fa-globe"></i> <span class="hide-sm">%s <i class="caret"></i></span></a>' % current_language_name
        
        # 添加隐藏的表单，用于语言切换
        language_html += '<form id="setlang-form" action="/xadmin/i18n/setlang/" method="post" style="display:none;">'  
        language_html += '<input type="hidden" name="csrfmiddlewaretoken" value="{{ csrf_token }}">'  
        language_html += '<input name="next" type="hidden" value="{{ request.path }}">'  
        language_html += '<input id="setlang-id_language" name="language" type="hidden" value="">'  
        language_html += '</form>'  
        
        # 使用id="g-setlang-menu"的ul元素
        language_html += '<ul id="g-setlang-menu" class="dropdown-menu" role="menu">'
        
        # 添加支持的语言选项，使用JavaScript来设置表单并提交
        for code, name in settings.LANGUAGES:
            if code == current_language:
                language_html += '<li class="active"><a href="#" onclick="setLanguage(\'%s\'); return false;">%s</a></li>' % (code, name)
            else:
                language_html += '<li><a href="#" onclick="setLanguage(\'%s\'); return false;">%s</a></li>' % (code, name)
        
        language_html += '</ul>'
        language_html += '</li>'
        
        # 添加到导航栏节点
        nodes.append(language_html)

# 注册插件
xadmin.site.register_plugin(LanguageSwitchPlugin, CommAdminView)

# 添加JavaScript以处理语言切换
xadmin.site.register_js("""
// 全局函数，用于设置语言并提交表单
function setLanguage(languageCode) {
    // 设置语言表单中的语言值
    $('#setlang-id_language').val(languageCode);
    // 设置当前路径作为next参数
    $('#setlang-form input[name="next"]').val(window.location.pathname + window.location.search);
    // 提交表单
    $('#setlang-form').submit();
}

$(function() {
    // 确保CSRF token正确设置
    if (!$('#setlang-form input[name="csrfmiddlewaretoken"]').val()) {
        // 如果没有CSRF token，尝试从cookie获取
        function getCookie(name) {
            let cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                const cookies = document.cookie.split(';');
                for (let i = 0; i < cookies.length; i++) {
                    const cookie = cookies[i].trim();
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }
        const csrftoken = getCookie('csrftoken');
        if (csrftoken) {
            $('#setlang-form input[name="csrfmiddlewaretoken"]').val(csrftoken);
        }
    }
    
    // 专门处理语言切换下拉菜单
    $('li.dropdown.g-setlang a.dropdown-toggle').off('click').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        // 切换下拉菜单显示状态
        $(this).parent().toggleClass('open');
    });
    
    // 点击语言选项时的处理
    $('#g-setlang-menu a').off('click').on('click', function(e) {
        // 点击后会调用setLanguage函数，这里只需要阻止事件冒泡
        e.stopPropagation();
    });
    
    // 点击其他地方关闭所有下拉菜单
    $(document).off('click.closeDropdown').on('click.closeDropdown', function(e) {
        if (!$(e.target).closest('li.dropdown.g-setlang').length) {
            $('li.dropdown.g-setlang').removeClass('open');
        }
    });
});
""")