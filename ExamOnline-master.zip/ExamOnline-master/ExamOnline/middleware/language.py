from django.utils import translation
from django.conf import settings

class LanguageMiddleware:
    """语言切换中间件"""
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        # 检查URL中的语言参数
        if 'set_language' in request.GET:
            language = request.GET.get('set_language')
            if language in [lang[0] for lang in settings.LANGUAGES]:
                # 存储语言选择到session
                request.session['_language'] = language
        
        # 从session中获取语言设置
        language = request.session.get('_language', settings.LANGUAGE_CODE)
        
        # 激活选定的语言
        translation.activate(language)
        request.LANGUAGE_CODE = translation.get_language()
        
        response = self.get_response(request)
        
        # 设置Content-Language响应头
        response['Content-Language'] = translation.get_language()
        
        return response