from django.shortcuts import redirect
from django.conf import settings
from django.utils import translation

def set_language(request):
    """处理语言切换请求"""
    next_url = request.GET.get('next', request.META.get('HTTP_REFERER', '/'))
    
    if 'language' in request.GET:
        language = request.GET.get('language')
        # 验证语言是否在支持的列表中
        if language in [lang[0] for lang in settings.LANGUAGES]:
            # 设置session中的语言
            request.session['_language'] = language
            # 激活语言
            translation.activate(language)
    
    return redirect(next_url)