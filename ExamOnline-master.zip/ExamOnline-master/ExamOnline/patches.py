# Django xadmin compatibility patch for WidgetTypeSelect.render()
# This patch fixes the TypeError: WidgetTypeSelect.render() got an unexpected keyword argument 'renderer'

import django.forms.boundfield
import functools

# 保存原始的as_widget方法
original_as_widget = django.forms.boundfield.BoundField.as_widget

# 创建一个新的as_widget方法，它会检查widget类名并在必要时移除renderer参数
@functools.wraps(original_as_widget)
def patched_as_widget(self, widget=None, attrs=None, only_initial=False):
    # 调用原始方法，但捕获可能的TypeError异常
    try:
        return original_as_widget(self, widget=widget, attrs=attrs, only_initial=only_initial)
    except TypeError as e:
        # 检查异常消息是否包含'renderer'关键字
        if 'renderer' in str(e):
            # 获取widget实例
            widget = widget or self.field.widget
            # 创建一个没有renderer参数的render方法包装器
            original_render = widget.render
            
            def patched_render(*args, **kwargs):
                # 移除renderer参数
                kwargs.pop('renderer', None)
                return original_render(*args, **kwargs)
            
            # 临时替换render方法
            widget.render = patched_render
            try:
                # 再次尝试调用原始方法
                return original_as_widget(self, widget=widget, attrs=attrs, only_initial=only_initial)
            finally:
                # 恢复原始render方法
                widget.render = original_render
        # 如果不是renderer参数导致的错误，重新抛出异常
        raise

# 应用补丁
django.forms.boundfield.BoundField.as_widget = patched_as_widget