"""ExamOnline URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
import xadmin
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls.i18n import i18n_patterns
from django.urls import path, include, re_path
from rest_framework.documentation import include_docs_urls
from ExamOnline.views import set_language
from rest_framework.routers import DefaultRouter
from rest_framework_jwt.views import obtain_jwt_token

from exam.views import GradeListViewSet, ExamListViewSet, PracticeListViewSet
from question.views import ChoiceListViewSet, FillListViewSet, JudgeListViewSet, ProgramListViewSet, CheckProgramApi
from record.views import ChoiceRecordListViewSet, FillRecordListViewSet, JudgeRecordListViewSet, \
    ProgramRecordListViewSet, MonitorRecordViewSet, CheatingDetectionViewSet, ExamBehaviorViewSet, CheatingAnalysisViewSet
from user.views import RegisterViewSet, StudentViewSet, UpdatePwdApi, ClazzListViewSet

router = DefaultRouter()

# 配置exams的url
router.register(r'exams', ExamListViewSet)
router.register(r'grades', GradeListViewSet)
router.register(r'choices', ChoiceListViewSet)
router.register(r'fills', FillListViewSet)
router.register(r'judges', JudgeListViewSet)
router.register(r'programs', ProgramListViewSet)
router.register(r'register', RegisterViewSet)
router.register(r'clazzs', ClazzListViewSet)
router.register(r'students', StudentViewSet)
router.register(r'practices', PracticeListViewSet)
router.register(r'records/choices', ChoiceRecordListViewSet)
router.register(r'records/fills', FillRecordListViewSet)
router.register(r'records/judges', JudgeRecordListViewSet)
router.register(r'records/programs', ProgramRecordListViewSet)
# 防作弊监控相关路由
router.register(r'monitor-records', MonitorRecordViewSet)
router.register(r'cheating-detections', CheatingDetectionViewSet)
router.register(r'exam-behaviors', ExamBehaviorViewSet)
router.register(r'cheating-analysis', CheatingAnalysisViewSet)

urlpatterns = [
    path('xadmin/', xadmin.site.urls),
    # path('docs/', include_docs_urls('Python多语种在线考试防作弊系统')),  # 暂时注释掉，避免coreapi导入错误
    path('jwt-auth/', obtain_jwt_token),  # JSON Web Token认证
    path('check-program/', CheckProgramApi.as_view()),
    path('update-pwd/', UpdatePwdApi.as_view()),
    path('i18n/set-language/', set_language, name='set_language'),
    path('api/', include(router.urls))
]

# 使用i18n_patterns包装需要支持多语言的URL
urlpatterns += i18n_patterns(
    # 这里可以添加需要多语言支持的URL
)

# 配置media文件访问路由
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
