from django.shortcuts import render
from django.db.models import Count, Sum

# Create your views here.
from rest_framework import mixins, viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response

from question.models import Program
from record.models import ChoiceRecord, FillRecord, JudgeRecord, ProgramRecord, MonitorRecord, CheatingDetection, ExamBehavior, CheatingAnalysis
from record.serializers import ChoiceRecordSerializer, FillRecordSerializer, JudgeRecordSerializer, \
    ProgramRecordSerializer, MonitorRecordSerializer, CheatingDetectionSerializer, ExamBehaviorSerializer, CheatingAnalysisSerializer


class ChoiceRecordListViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    """选择题练习记录"""
    # 数据集
    queryset = ChoiceRecord.objects.all()
    # 序列化
    serializer_class = ChoiceRecordSerializer

    def get_queryset(self):
        # 模拟练习ID
        practice_id = self.request.query_params.get('practice_id')
        student_id = self.request.query_params.get('student_id')
        
        if practice_id:
            self.queryset = self.queryset.filter(practice_id=practice_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class FillRecordListViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    """填空题练习记录"""
    # 数据集
    queryset = FillRecord.objects.all()
    # 序列化
    serializer_class = FillRecordSerializer

    def get_queryset(self):
        # 模拟练习ID
        practice_id = self.request.query_params.get('practice_id')
        student_id = self.request.query_params.get('student_id')
        
        if practice_id:
            self.queryset = self.queryset.filter(practice_id=practice_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class JudgeRecordListViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    """判断题练习记录"""
    # 数据集
    queryset = JudgeRecord.objects.all()
    # 序列化
    serializer_class = JudgeRecordSerializer

    def get_queryset(self):
        # 模拟练习ID
        practice_id = self.request.query_params.get('practice_id')
        student_id = self.request.query_params.get('student_id')
        
        if practice_id:
            self.queryset = self.queryset.filter(practice_id=practice_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class ProgramRecordListViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    """编程题练习记录"""
    # 数据集
    queryset = ProgramRecord.objects.all()
    # 序列化
    serializer_class = ProgramRecordSerializer

    def get_queryset(self):
        # 模拟练习ID
        practice_id = self.request.query_params.get('practice_id')
        student_id = self.request.query_params.get('student_id')
        
        if practice_id:
            self.queryset = self.queryset.filter(practice_id=practice_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class MonitorRecordViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    """监控记录视图集"""
    queryset = MonitorRecord.objects.all()
    serializer_class = MonitorRecordSerializer
    
    def get_queryset(self):
        # 根据考试ID和学生ID过滤
        exam_id = self.request.query_params.get('exam_id')
        student_id = self.request.query_params.get('student_id')
        
        if exam_id:
            self.queryset = self.queryset.filter(exam_id=exam_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class CheatingDetectionViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, mixins.RetrieveModelMixin, viewsets.GenericViewSet):
    """作弊检测视图集"""
    queryset = CheatingDetection.objects.all()
    serializer_class = CheatingDetectionSerializer
    
    def get_queryset(self):
        # 根据考试ID和学生ID过滤
        exam_id = self.request.query_params.get('exam_id')
        student_id = self.request.query_params.get('student_id')
        
        if exam_id:
            self.queryset = self.queryset.filter(exam_id=exam_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class ExamBehaviorViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, viewsets.GenericViewSet):
    """考试行为视图集"""
    queryset = ExamBehavior.objects.all()
    serializer_class = ExamBehaviorSerializer
    
    def get_queryset(self):
        # 根据考试ID和学生ID过滤
        exam_id = self.request.query_params.get('exam_id')
        student_id = self.request.query_params.get('student_id')
        
        if exam_id:
            self.queryset = self.queryset.filter(exam_id=exam_id)
        if student_id:
            self.queryset = self.queryset.filter(student_id=student_id)
        
        return self.queryset


class CheatingAnalysisViewSet(viewsets.ModelViewSet):
    """作弊分析结果视图集"""
    queryset = CheatingAnalysis.objects.all()
    serializer_class = CheatingAnalysisSerializer
    
    def get_queryset(self):
        # 根据考试ID和学生ID过滤
        exam_id = self.request.query_params.get('exam_id')
        student_id = self.request.query_params.get('student_id')
        risk_level = self.request.query_params.get('risk_level')
        
        queryset = self.queryset
        if exam_id:
            queryset = queryset.filter(exam_id=exam_id)
        if student_id:
            queryset = queryset.filter(student_id=student_id)
        if risk_level:
            queryset = queryset.filter(risk_level=risk_level)
        
        return queryset
    
    @action(detail=False, methods=['post'], url_path='analyze-exam')
    def analyze_exam(self, request):
        """分析指定考试的所有学生的作弊情况"""
        exam_id = request.data.get('exam_id')
        
        if not exam_id:
            return Response({'error': '考试ID不能为空'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # 获取该考试的所有作弊检测记录，按学生分组统计
            student_cheating_stats = CheatingDetection.objects.filter(exam_id=exam_id).values(
                'student_id').annotate(
                total_count=Count('id'),
                total_score=Sum('severity')
            )
            
            # 分析每个学生的作弊情况
            results = []
            for stat in student_cheating_stats:
                student_id = stat['student_id']
                
                # 获取该学生的所有作弊记录
                cheating_records = CheatingDetection.objects.filter(
                    exam_id=exam_id, student_id=student_id
                )
                
                # 统计各类型作弊次数
                type_counts = {}
                for record in cheating_records:
                    if record.detection_type in type_counts:
                        type_counts[record.detection_type] += 1
                    else:
                        type_counts[record.detection_type] = 1
                
                # 找出最频繁的作弊类型
                most_frequent_type = max(type_counts, key=type_counts.get) if type_counts else None
                
                # 获取首次和最后一次作弊时间
                first_cheating = cheating_records.order_by('detection_time').first()
                last_cheating = cheating_records.order_by('-detection_time').first()
                
                # 统计考试行为
                page_changes = ExamBehavior.objects.filter(
                    exam_id=exam_id, student_id=student_id, 
                    behavior_type__in=['page_focus', 'page_blur']
                ).count()
                
                fullscreen_exits = ExamBehavior.objects.filter(
                    exam_id=exam_id, student_id=student_id, 
                    behavior_type='fullscreen_exit'
                ).count()
                
                # 计算风险等级
                total_score = stat['total_score']
                if total_score >= 10:
                    risk_level = '严重'
                elif total_score >= 5:
                    risk_level = '高'
                elif total_score >= 3:
                    risk_level = '中'
                else:
                    risk_level = '低'
                
                # 生成分析结论
                conclusion = self._generate_conclusion(risk_level, type_counts, most_frequent_type)
                
                # 创建或更新分析记录
                analysis = CheatingAnalysis.objects.update_or_create(
                    exam_id=exam_id, student_id=student_id,
                    defaults={
                        'total_cheating_count': stat['total_count'],
                        'total_cheating_score': total_score,
                        'risk_level': risk_level,
                        'most_frequent_cheating_type': most_frequent_type,
                        'first_cheating_time': first_cheating.detection_time if first_cheating else None,
                        'last_cheating_time': last_cheating.detection_time if last_cheating else None,
                        'page_focus_change_count': page_changes,
                        'fullscreen_exit_count': fullscreen_exits,
                        'copy_paste_attempt_count': type_counts.get('copy_paste', 0),
                        'analysis_conclusion': conclusion
                    }
                )[0]  # 获取对象而不是元组
                # 使用方法设置作弊类型计数
                analysis.set_cheating_type_counts(type_counts)
                analysis.save()
                
                results.append(CheatingAnalysisSerializer(analysis).data)
            
            return Response({
                'success': True,
                'analyzed_students': len(results),
                'data': results
            })
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    @action(detail=False, methods=['get'], url_path='get-statistics')
    def get_statistics(self, request):
        """获取作弊统计数据用于可视化"""
        exam_id = request.query_params.get('exam_id')
        
        if not exam_id:
            return Response({'error': '考试ID不能为空'}, status=status.HTTP_400_BAD_REQUEST)
        
        try:
            # 获取风险等级分布
            risk_distribution = CheatingAnalysis.objects.filter(exam_id=exam_id).values(
                'risk_level').annotate(count=Count('id'))
            
            # 获取作弊类型分布
            cheating_records = CheatingDetection.objects.filter(exam_id=exam_id)
            type_distribution = {}
            for record in cheating_records:
                type_name = dict(CheatingDetection.DETECTION_TYPES).get(record.detection_type, record.detection_type)
                if type_name in type_distribution:
                    type_distribution[type_name] += 1
                else:
                    type_distribution[type_name] = 1
            
            # 获取风险最高的前5名学生
            top_risk_students = CheatingAnalysis.objects.filter(exam_id=exam_id).order_by(
                '-total_cheating_score')[:5]
            top_students_data = []
            for student in top_risk_students:
                top_students_data.append({
                    'name': student.student.name,
                    'username': student.student.username,
                    'risk_score': student.total_cheating_score,
                    'risk_level': student.risk_level,
                    'cheating_count': student.total_cheating_count
                })
            
            # 获取时间段分布（按小时统计作弊次数）
            hour_distribution = {}
            for record in cheating_records:
                hour = record.detection_time.hour
                hour_str = f'{hour}:00'
                if hour_str in hour_distribution:
                    hour_distribution[hour_str] += 1
                else:
                    hour_distribution[hour_str] = 1
            
            return Response({
                'success': True,
                'risk_distribution': list(risk_distribution),
                'type_distribution': type_distribution,
                'top_risk_students': top_students_data,
                'hour_distribution': hour_distribution,
                'total_cheating_records': cheating_records.count(),
                'total_risky_students': CheatingAnalysis.objects.filter(
                    exam_id=exam_id, risk_level__in=['高', '严重']
                ).count()
            })
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    def _generate_conclusion(self, risk_level, type_counts, most_frequent_type):
        """根据分析结果生成结论"""
        if risk_level == '严重':
            return f'该学生存在严重作弊嫌疑，主要表现为{most_frequent_type}行为。建议重点审查。'
        elif risk_level == '高':
            return f'该学生有较高作弊风险，{most_frequent_type}行为较为频繁。建议进行适当处理。'
        elif risk_level == '中':
            return f'该学生存在中等作弊风险，有{most_frequent_type}等异常行为。建议关注。'
        else:
            return '该学生作弊风险较低，考试行为基本正常。'
