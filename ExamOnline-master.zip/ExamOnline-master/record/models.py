from django.db import models
from datetime import datetime
import json

# Create your models here.
from exam.models import Practice, Exam
from question.models import Choice, Fill, Judge, Program
from user.models import Student


class Record(models.Model):
    """练习记录"""
    practice = models.ForeignKey(Practice, verbose_name="练习", on_delete=models.CASCADE)
    student = models.ForeignKey(Student, verbose_name="学生", on_delete=models.CASCADE)
    your_answer = models.TextField("你的作答", null=True, blank=True)

    class Meta:
        # 抽象类
        abstract = True

    def __str__(self):
        return self.your_answer


class ChoiceRecord(Record):
    """选择题答题记录"""
    choice = models.ForeignKey(Choice, verbose_name="选择题", on_delete=models.CASCADE)

    class Meta:
        ordering = ['id']
        verbose_name = '选择题答题记录'
        verbose_name_plural = verbose_name


class FillRecord(Record):
    """填空题答题记录"""
    fill = models.ForeignKey(Fill, verbose_name="填空题", on_delete=models.CASCADE)

    class Meta:
        ordering = ['id']
        verbose_name = '填空题答题记录'
        verbose_name_plural = verbose_name


class JudgeRecord(Record):
    judge = models.ForeignKey(Judge, verbose_name="判断题", on_delete=models.CASCADE)

    class Meta:
        ordering = ['id']
        verbose_name = '判断题答题记录'
        verbose_name_plural = verbose_name


class ProgramRecord(Record):
    program = models.ForeignKey(Program, verbose_name="编程题", on_delete=models.CASCADE)
    cmd_msg = models.TextField("输出结果", null=True, blank=True)

    class Meta:
        ordering = ['id']
        verbose_name = '编程题答题记录'
        verbose_name_plural = verbose_name


class MonitorRecord(models.Model):
    """监控记录模型 - 存储摄像头捕获的图像和监控数据"""
    exam = models.ForeignKey(Exam, verbose_name="考试", on_delete=models.CASCADE)
    student = models.ForeignKey(Student, verbose_name="学生", on_delete=models.CASCADE)
    capture_time = models.DateTimeField("捕获时间", auto_now_add=True)
    image_data = models.TextField("图像数据(Base64)", null=True, blank=True)
    status = models.CharField("状态", max_length=20, default="normal", help_text="normal:正常, suspicious:可疑")
    remarks = models.TextField("备注", null=True, blank=True)

    class Meta:
        ordering = ['-capture_time']
        verbose_name = '监控记录'
        verbose_name_plural = verbose_name


class CheatingDetection(models.Model):
    """作弊检测模型 - 记录检测到的作弊行为"""
    DETECTION_TYPES = (
        ('camera_absence', '摄像头未检测到人'),
        ('browser_switch', '浏览器切换'),
        ('tab_change', '标签页切换'),
        ('screen_share', '屏幕共享'),
        ('copy_paste', '复制粘贴尝试'),
        ('fullscreen_exit', '退出全屏'),
        ('other', '其他异常')
    )
    exam = models.ForeignKey(Exam, verbose_name="考试", on_delete=models.CASCADE)
    student = models.ForeignKey(Student, verbose_name="学生", on_delete=models.CASCADE)
    detection_type = models.CharField("检测类型", max_length=20, choices=DETECTION_TYPES)
    detection_time = models.DateTimeField("检测时间", auto_now_add=True)
    severity = models.IntegerField("严重程度", default=1, help_text="1-轻微, 2-中等, 3-严重")
    description = models.TextField("描述", null=True, blank=True)
    evidence = models.TextField("证据(Base64)", null=True, blank=True)

    class Meta:
        ordering = ['-detection_time']
        verbose_name = '作弊检测记录'
        verbose_name_plural = verbose_name


class ExamBehavior(models.Model):
    """考试行为模型 - 记录考生的考试行为"""
    BEHAVIOR_TYPES = (
        ('question_view', '查看题目'),
        ('answer_change', '修改答案'),
        ('page_focus', '页面获得焦点'),
        ('page_blur', '页面失去焦点'),
        ('fullscreen_enter', '进入全屏'),
        ('fullscreen_exit', '退出全屏'),
        ('time_spent', '时间花费'),
        ('submit_answer', '提交答案'),
        ('no_activity', '长时间无操作'),
        ('camera_start', '摄像头开启')
    )
    exam = models.ForeignKey(Exam, verbose_name="考试", on_delete=models.CASCADE)
    student = models.ForeignKey(Student, verbose_name="学生", on_delete=models.CASCADE)
    behavior_type = models.CharField("行为类型", max_length=20, choices=BEHAVIOR_TYPES)
    behavior_time = models.DateTimeField("行为时间", auto_now_add=True)
    question_id = models.IntegerField("题目ID", null=True, blank=True)
    duration = models.FloatField("持续时间(秒)", null=True, blank=True)
    details = models.TextField("详细信息", null=True, blank=True)

    class Meta:
        ordering = ['behavior_time']
        verbose_name = '考试行为记录'
        verbose_name_plural = verbose_name


class CheatingAnalysis(models.Model):
    """作弊分析结果模型 - 存储对作弊行为的统计和分析结果"""
    exam = models.ForeignKey(Exam, verbose_name="考试", on_delete=models.CASCADE)
    student = models.ForeignKey(Student, verbose_name="学生", on_delete=models.CASCADE)
    analysis_time = models.DateTimeField("分析时间", auto_now_add=True)
    total_cheating_count = models.IntegerField("作弊行为总数", default=0)
    total_cheating_score = models.FloatField("作弊风险总分", default=0)
    risk_level = models.CharField("风险等级", max_length=20, default="低", choices=[
        ('低', '低'),
        ('中', '中'),
        ('高', '高'),
        ('严重', '严重')
    ])
    cheating_type_counts = models.TextField("各类型作弊次数统计", default='{}')
    
    def get_cheating_type_counts(self):
        """获取各类型作弊次数统计"""
        try:
            return json.loads(self.cheating_type_counts) if self.cheating_type_counts else {}
        except json.JSONDecodeError:
            return {}
    
    def set_cheating_type_counts(self, counts):
        """设置各类型作弊次数统计"""
        self.cheating_type_counts = json.dumps(counts, ensure_ascii=False)
    most_frequent_cheating_type = models.CharField("最频繁作弊类型", max_length=20, null=True, blank=True)
    first_cheating_time = models.DateTimeField("首次作弊时间", null=True, blank=True)
    last_cheating_time = models.DateTimeField("最后作弊时间", null=True, blank=True)
    page_focus_change_count = models.IntegerField("页面焦点变化次数", default=0)
    fullscreen_exit_count = models.IntegerField("退出全屏次数", default=0)
    copy_paste_attempt_count = models.IntegerField("复制粘贴尝试次数", default=0)
    analysis_conclusion = models.TextField("分析结论", null=True, blank=True)
    
    def __str__(self):
        """返回作弊分析记录的字符串表示"""
        return f"{self.exam} - {self.student} - {self.risk_level}"

    class Meta:
        ordering = ['-analysis_time']
        verbose_name = '作弊分析结果'
        verbose_name_plural = '作弊分析结果'
        unique_together = ('exam', 'student')  # 确保每个学生每场考试只有一条分析记录
