from rest_framework import serializers

from exam.models import Practice, Exam
from exam.serializers import PracticeSerializer
from question.models import Choice, Fill, Judge, Program
from question.serializers import ChoiceSerializer, FillSerializer, JudgeSerializer, ProgramSerializer
from record.models import ChoiceRecord, FillRecord, ProgramRecord, JudgeRecord, MonitorRecord, CheatingDetection, ExamBehavior, CheatingAnalysis
from user.models import Student
from user.serializers import StudentSerializer


class ChoiceRecordSerializer(serializers.ModelSerializer):
    # 覆盖外键字段 只读
    practice = PracticeSerializer(read_only=True)
    student = StudentSerializer(read_only=True)
    choice = ChoiceSerializer(read_only=True)

    # 用于创建的只写字段
    practice_id = serializers.PrimaryKeyRelatedField(queryset=Practice.objects.all(), source='practice',
                                                     write_only=True)
    student_id = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all(), source='student', write_only=True)
    choice_id = serializers.PrimaryKeyRelatedField(queryset=Choice.objects.all(), source='choice', write_only=True)

    class Meta:
        model = ChoiceRecord
        fields = '__all__'


class FillRecordSerializer(serializers.ModelSerializer):
    # 覆盖外键字段 只读
    practice = PracticeSerializer(read_only=True)
    student = StudentSerializer(read_only=True)
    fill = FillSerializer(read_only=True)

    # 用于创建的只写字段
    practice_id = serializers.PrimaryKeyRelatedField(queryset=Practice.objects.all(), source='practice',
                                                     write_only=True)
    student_id = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all(), source='student', write_only=True)
    fill_id = serializers.PrimaryKeyRelatedField(queryset=Fill.objects.all(), source='fill', write_only=True)

    class Meta:
        model = FillRecord
        fields = '__all__'


class JudgeRecordSerializer(serializers.ModelSerializer):
    # 覆盖外键字段 只读
    practice = PracticeSerializer(read_only=True)
    student = StudentSerializer(read_only=True)
    judge = JudgeSerializer(read_only=True)

    # 用于创建的只写字段
    practice_id = serializers.PrimaryKeyRelatedField(queryset=Practice.objects.all(), source='practice',
                                                     write_only=True)
    student_id = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all(), source='student', write_only=True)
    judge_id = serializers.PrimaryKeyRelatedField(queryset=Judge.objects.all(), source='judge', write_only=True)

    class Meta:
        model = JudgeRecord
        fields = '__all__'


class ProgramRecordSerializer(serializers.ModelSerializer):
    # 覆盖外键字段 只读
    practice = PracticeSerializer(read_only=True)
    student = StudentSerializer(read_only=True)
    program = ProgramSerializer(read_only=True)

    # 用于创建的只写字段
    practice_id = serializers.PrimaryKeyRelatedField(queryset=Practice.objects.all(), source='practice',
                                                     write_only=True)
    student_id = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all(), source='student', write_only=True)
    program_id = serializers.PrimaryKeyRelatedField(queryset=Program.objects.all(), source='program', write_only=True)

    class Meta:
        model = ProgramRecord
        fields = '__all__'


class MonitorRecordSerializer(serializers.ModelSerializer):
    """监控记录序列化器"""
    # 覆盖外键字段 只读
    exam = serializers.CharField(source='exam.name', read_only=True)
    student = serializers.CharField(source='student.name', read_only=True)
    
    # 用于创建的只写字段 - 使用IntegerField允许直接传递ID值
    exam_id = serializers.IntegerField(write_only=True)
    student_id = serializers.IntegerField(write_only=True)
    
    def create(self, validated_data):
        # 提取exam_id和student_id
        exam_id = validated_data.pop('exam_id')
        student_id = validated_data.pop('student_id')
        
        # 创建MonitorRecord对象，设置外键关系
        from exam.models import Exam
        from user.models import Student
        
        try:
            exam = Exam.objects.get(id=exam_id)
            student = Student.objects.get(id=student_id)
            
            # 创建对象并设置外键
            return MonitorRecord.objects.create(
                exam=exam,
                student=student,
                **validated_data
            )
        except (Exam.DoesNotExist, Student.DoesNotExist) as e:
            # 记录错误信息并抛出ValidationError
            from rest_framework.exceptions import ValidationError
            raise ValidationError(f'关联对象不存在: {str(e)}')
    
    class Meta:
        model = MonitorRecord
        fields = '__all__'


class CheatingDetectionSerializer(serializers.ModelSerializer):
    """作弊检测序列化器"""
    # 覆盖外键字段 只读
    exam = serializers.CharField(source='exam.name', read_only=True)
    student = serializers.CharField(source='student.name', read_only=True)
    detection_type_text = serializers.CharField(source='get_detection_type_display', read_only=True)
    
    # 用于创建的只写字段 - 使用IntegerField允许直接传递ID值
    exam_id = serializers.IntegerField(write_only=True)
    student_id = serializers.IntegerField(write_only=True)
    
    def create(self, validated_data):
        # 提取exam_id和student_id
        exam_id = validated_data.pop('exam_id')
        student_id = validated_data.pop('student_id')
        
        # 创建CheatingDetection对象，设置外键关系
        from exam.models import Exam
        from user.models import Student
        
        try:
            exam = Exam.objects.get(id=exam_id)
            student = Student.objects.get(id=student_id)
            
            # 创建对象并设置外键
            return CheatingDetection.objects.create(
                exam=exam,
                student=student,
                **validated_data
            )
        except (Exam.DoesNotExist, Student.DoesNotExist) as e:
            # 记录错误信息并抛出ValidationError
            from rest_framework.exceptions import ValidationError
            raise ValidationError(f'关联对象不存在: {str(e)}')
    
    class Meta:
        model = CheatingDetection
        # 手动列出所有字段并添加自定义字段
        fields = ['id', 'exam', 'student', 'detection_type', 'severity', 'description', 'evidence', 'detection_time', 'detection_type_text', 'exam_id', 'student_id']


class ExamBehaviorSerializer(serializers.ModelSerializer):
    """考试行为序列化器"""
    # 覆盖外键字段 只读
    exam = serializers.CharField(source='exam.name', read_only=True)
    student = serializers.CharField(source='student.name', read_only=True)
    behavior_type_text = serializers.CharField(source='get_behavior_type_display', read_only=True)
    # 明确设置behavior_time为read_only，因为模型中设置了auto_now_add=True
    behavior_time = serializers.DateTimeField(read_only=True)
    
    # 用于创建的只写字段 - 使用IntegerField允许直接传递ID值
    exam_id = serializers.IntegerField(write_only=True)
    student_id = serializers.IntegerField(write_only=True)
    
    def validate(self, data):
        # 添加验证逻辑，记录接收到的数据
        print(f"接收到的数据: {data}")
        return data
    
    def create(self, validated_data):
        # 提取exam_id和student_id
        exam_id = validated_data.pop('exam_id')
        student_id = validated_data.pop('student_id')
        
        # 创建ExamBehavior对象，设置外键关系
        from exam.models import Exam
        from user.models import Student
        
        try:
            # 记录查询信息
            print(f"尝试查询考试ID: {exam_id}, 学生ID: {student_id}")
            
            exam = Exam.objects.get(id=exam_id)
            student = Student.objects.get(id=student_id)
            
            print(f"查询成功，准备创建记录: {validated_data}")
            
            # 创建对象并设置外键
            return ExamBehavior.objects.create(
                exam=exam,
                student=student,
                **validated_data
            )
        except Exam.DoesNotExist:
            # 记录错误信息并抛出ValidationError
            error_msg = f'考试ID {exam_id} 不存在'
            print(f"错误: {error_msg}")
            from rest_framework.exceptions import ValidationError
            raise ValidationError(error_msg)
        except Student.DoesNotExist:
            error_msg = f'学生ID {student_id} 不存在'
            print(f"错误: {error_msg}")
            from rest_framework.exceptions import ValidationError
            raise ValidationError(error_msg)
        except Exception as e:
            # 捕获其他所有异常
            error_msg = f'创建行为记录时出错: {str(e)}'
            print(f"错误: {error_msg}")
            from rest_framework.exceptions import ValidationError
            raise ValidationError(error_msg)
    
    class Meta:
        model = ExamBehavior
        fields = ['id', 'exam', 'student', 'behavior_type', 'behavior_time', 'question_id', 'duration', 'details', 'behavior_type_text', 'exam_id', 'student_id']


class CheatingAnalysisSerializer(serializers.ModelSerializer):
    """作弊分析结果序列化器"""
    # 覆盖外键字段 只读
    exam = serializers.CharField(source='exam.name', read_only=True)
    student = serializers.CharField(source='student.name', read_only=True)
    student_info = serializers.SerializerMethodField(read_only=True)
    exam_info = serializers.SerializerMethodField(read_only=True)
    cheating_type_counts = serializers.SerializerMethodField(read_only=True)
    
    # 用于创建的只写字段
    exam_id = serializers.PrimaryKeyRelatedField(queryset=Exam.objects.all(), source='exam', write_only=True)
    student_id = serializers.PrimaryKeyRelatedField(queryset=Student.objects.all(), source='student', write_only=True)
    
    def get_student_info(self, obj):
        """获取学生详细信息"""
        return {
            'id': obj.student.id,
            'name': obj.student.name,
            'username': obj.student.username,
            'clazz': obj.student.clazz.name if obj.student.clazz else '',
            'major': obj.student.clazz.major if obj.student.clazz else ''
        }
    
    def get_exam_info(self, obj):
        """获取考试详细信息"""
        return {
            'id': obj.exam.id,
            'name': obj.exam.name,
            'start_time': obj.exam.start_time.strftime('%Y-%m-%d %H:%M:%S') if obj.exam.start_time else '',
            'end_time': obj.exam.end_time.strftime('%Y-%m-%d %H:%M:%S') if obj.exam.end_time else ''
        }
    
    def get_cheating_type_counts(self, obj):
        """获取各类型作弊次数统计"""
        return obj.get_cheating_type_counts()
    
    class Meta:
        model = CheatingAnalysis
        fields = ['id', 'exam', 'student', 'analysis_time', 'risk_level', 'report', 'student_info', 'exam_info', 'cheating_type_counts', 'exam_id', 'student_id']
