import xadmin
from xadmin import views
from record.models import MonitorRecord, CheatingDetection, ExamBehavior, CheatingAnalysis
from xadmin.layout import Main, Fieldset, Row
import json


@xadmin.sites.register(MonitorRecord)
class MonitorRecordAdmin(object):
    """监控记录管理"""
    list_display = ['exam', 'student', 'capture_time', 'status']
    search_fields = ['student__name', 'student__username', 'exam__name']
    list_filter = ['exam', 'student', 'status', 'capture_time']
    readonly_fields = ['capture_time']
    ordering = ['-capture_time']


@xadmin.sites.register(CheatingDetection)
class CheatingDetectionAdmin(object):
    """作弊检测记录管理"""
    list_display = ['exam', 'student', 'detection_type', 'severity', 'detection_time']
    search_fields = ['student__name', 'student__username', 'exam__name']
    list_filter = ['exam', 'student', 'detection_type', 'severity', 'detection_time']
    readonly_fields = ['detection_time']
    ordering = ['-detection_time']


@xadmin.sites.register(ExamBehavior)
class ExamBehaviorAdmin(object):
    """考试行为记录管理"""
    list_display = ['exam', 'student', 'behavior_type', 'behavior_time']
    search_fields = ['student__name', 'student__username', 'exam__name']
    list_filter = ['exam', 'student', 'behavior_type', 'behavior_time']
    readonly_fields = ['behavior_time']
    ordering = ['-behavior_time']


@xadmin.sites.register(CheatingAnalysis)
class CheatingAnalysisAdmin(object):
    """作弊分析结果管理"""
    list_display = ['exam', 'student', 'total_cheating_count', 'total_cheating_score', 'risk_level', 'analysis_time']
    search_fields = ['student__name', 'student__username', 'exam__name']
    list_filter = ['exam', 'student', 'risk_level', 'analysis_time']
    readonly_fields = ['analysis_time', 'cheating_type_counts_display', 'analysis_conclusion']
    ordering = ['-total_cheating_score']
    
    # 自定义显示字段
    def cheating_type_counts_display(self, obj):
        """格式化显示各类型作弊次数统计"""
        if obj.cheating_type_counts:
            # 获取检测类型的中文映射
            type_mapping = dict(CheatingDetection.DETECTION_TYPES)
            # 将类型代码转换为中文名称
            formatted = []
            for type_code, count in obj.cheating_type_counts.items():
                type_name = type_mapping.get(type_code, type_code)
                formatted.append(f"{type_name}: {count}次")
            return "<br>".join(formatted)
        return "无"
    
    cheating_type_counts_display.short_description = "各类型作弊次数"
    cheating_type_counts_display.allow_tags = True
    
    # 详情页布局
    def get_form_layout(self):
        return (
            Main(
                Fieldset("基本信息",
                    'exam', 'student', 'analysis_time'
                ),
                Fieldset("作弊统计",
                    Row('total_cheating_count', 'total_cheating_score'),
                    Row('risk_level', 'most_frequent_cheating_type'),
                    Row('first_cheating_time', 'last_cheating_time'),
                ),
                Fieldset("行为详细",
                    Row('page_focus_change_count', 'fullscreen_exit_count'),
                    Row('copy_paste_attempt_count'),
                    'cheating_type_counts_display',
                ),
                Fieldset("分析结论",
                    'analysis_conclusion'
                ),
            )
        )
    
    # 自定义操作
    actions = ['analyze_selected']
    
    def analyze_selected(self, request, queryset):
        """重新分析选中的记录"""
        from rest_framework.test import APIRequestFactory
        from record.views import CheatingAnalysisViewSet
        
        # 获取唯一的考试ID
        exam_ids = set(obj.exam_id for obj in queryset)
        if len(exam_ids) > 1:
            self.message_user(request, "请选择同一考试的记录进行分析", 'warning')
            return
        
        exam_id = exam_ids.pop() if exam_ids else None
        if not exam_id:
            self.message_user(request, "未找到有效的考试信息", 'error')
            return
        
        try:
            # 创建API请求并调用分析方法
            factory = APIRequestFactory()
            view = CheatingAnalysisViewSet.as_view({'post': 'analyze_exam'})
            request = factory.post('/api/cheating-analysis/analyze-exam/', {'exam_id': exam_id})
            response = view(request)
            
            if response.status_code == 200:
                self.message_user(request, f"成功分析了{response.data.get('analyzed_students', 0)}名学生的作弊数据", 'success')
            else:
                self.message_user(request, f"分析失败: {response.data.get('error', '未知错误')}", 'error')
        except Exception as e:
            self.message_user(request, f"分析过程中出错: {str(e)}", 'error')
    
    analyze_selected.short_description = "重新分析选中的考试作弊数据"


# 注册作弊分析仪表盘
@xadmin.sites.register(views.website.IndexView)
class MainDashboard(object):
    widgets = (
        [
            {"type": "html", "title": "作弊监控概览", 
             "content": """
             <div style="padding: 15px;">
                 <h3 style="margin-top: 0;">作弊监控系统</h3>
                 <p>点击左侧菜单的"作弊分析结果"查看详细分析数据。</p>
                 <p>支持考试作弊行为的统计分析和可视化展示。</p>
             </div>
             """},
        ],
    )