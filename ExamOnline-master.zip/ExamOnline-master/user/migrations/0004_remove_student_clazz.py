
from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0003_auto_20200425_2103'),
    ]

    operations = [
        # migrations.RemoveField(
        #     model_name='student',
        #     name='clazz',
        # ),
    ]
