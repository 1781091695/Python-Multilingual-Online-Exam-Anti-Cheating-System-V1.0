
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    dependencies = [
        ('user', '0002_auto_20200425_1959'),
    ]

    operations = [
        migrations.CreateModel(
            name='Clazz',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('year', models.CharField(max_length=20, verbose_name='年级')),
                ('major', models.CharField(max_length=20, verbose_name='专业')),
                ('clazz', models.CharField(max_length=20, verbose_name='班级')),
            ],
            options={
                'verbose_name': '班级',
                'verbose_name_plural': '班级',
                'ordering': ['id'],
            },
        ),
        # migrations.AddField(
        #     model_name='student',
        #     name='clazz',
        #     field=models.ForeignKey(default=4, on_delete=django.db.models.deletion.CASCADE, to='user.Clazz', verbose_name='班级'),
        #     preserve_default=False,
        # ),
    ]
