from django.contrib.auth.models import User
from rest_framework import serializers

from user.models import Student, Clazz


class ClazzSerializer(serializers.ModelSerializer):
    # 添加name字段，使用模型的__str__方法返回格式化的班级名称
    name = serializers.ReadOnlyField(source='__str__')
    
    class Meta:
        model = Clazz
        fields = ['id', 'year', 'major', 'clazz', 'name']  # 明确指定字段，确保name字段被包含


class UserDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'password', 'first_name', 'last_name', 'email')
        extra_kwargs = {
            'password': {'write_only': True},
            'first_name': {'read_only': True},
            'last_name': {'read_only': True},
            'email': {'read_only': True}
        }


class StudentSerializer(serializers.ModelSerializer):
    # 覆盖外键字段 只读
    # user = UserDetailSerializer()
    clazz = ClazzSerializer(read_only=True)

    # 用于创建的只写字段
    clazz_id = serializers.PrimaryKeyRelatedField(queryset=Clazz.objects.all(), source='clazz', write_only=True)

    class Meta:
        model = Student
        fields = '__all__'
