from import_export import resources, fields
from django.contrib.auth.models import User
import random

from user.models import Student


class StudentResource(resources.ModelResource):
    # 自定义字段映射，使用id作为username的来源
    name = fields.Field(attribute='name', column_name='姓名')
    gender = fields.Field(attribute='gender', column_name='性别')
    clazz = fields.Field(attribute='clazz', column_name='班级')
    
    def before_import_row(self, row, **kwargs):
        # 确保gender字段值正确映射到'm'或'f'
        if row.get('性别') == '男':
            row['性别'] = 'm'
        elif row.get('性别') == '女':
            row['性别'] = 'f'
    
    def before_save_instance(self, instance, using_transactions, dry_run):
        # 如果是新建实例且没有关联user，则自动创建user
        if not instance.user_id:
            # 生成唯一的用户名，使用学生ID和随机数
            student_id = instance.id or random.randint(100000, 999999)
            username = f'student_{student_id}'
            
            # 确保用户名唯一
            while User.objects.filter(username=username).exists():
                username = f'student_{student_id}_{random.randint(100, 999)}'
            
            # 创建用户对象
            user = User.objects.create(
                username=username,
                password='123456'  # 默认密码，用户可以后续修改
            )
            
            # 设置密码（必须通过set_password方法）
            user.set_password('123456')
            user.save()
            
            # 关联用户到学生实例
            instance.user = user

    class Meta:
        model = Student
        fields = ('id', 'name', 'user', 'gender', 'clazz')
        # 导入时使用的字段映射
        import_id_fields = ['id']  # 使用id作为导入的标识字段