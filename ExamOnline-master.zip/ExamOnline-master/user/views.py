from django.contrib.auth.backends import ModelBackend
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.db.models import Q
from rest_framework import viewsets, mixins, status, permissions
from rest_framework.response import Response
from rest_framework.views import APIView

from user.models import Student, Clazz
from user.serializers import StudentSerializer, UserDetailSerializer, ClazzSerializer


# Create your views here.
class CustomBackend(ModelBackend):
    """
    自定义用户验证
    """

    def authenticate(self, username=None, password=None, **kwargs):
        try:
            user = User.objects.get(Q(username=username) | Q(mobile=username))
            if user.check_password(password):
                return user
        except Exception as e:
            return None


def jwt_response_payload_handler(token, user=None, request=None):
    """
    设置jwt登录之后返回token和user信息
    """
    student = Student.objects.get(user=user)
    return {
        'token': token,
        'user': UserDetailSerializer(user, context={'request': request}).data,
        'student': StudentSerializer(student, context={'request': request}).data
    }


class RegisterViewSet(mixins.CreateModelMixin, viewsets.GenericViewSet):
    """
    用户注册
    """
    queryset = User.objects.all()
    serializer_class = UserDetailSerializer
    permission_classes = (permissions.AllowAny,)

    def create(self, request, *args, **kwargs):
        # 检查用户名是否已存在
        username = request.data.get('username')
        if User.objects.filter(username=username).exists():
            return Response({'msg': '用户名已存在', 'status': 'error'}, status=status.HTTP_200_OK)
            
        # 验证必要字段
        if not request.data.get('password'):
            return Response({'msg': '密码不能为空', 'status': 'error'}, status=status.HTTP_200_OK)
        
        # 创建用户
        user_data = request.data.copy()
        user_detail = UserDetailSerializer(data=user_data)
        
        if user_detail.is_valid():
            # 保存用户并设置密码
            user = user_detail.save()
            user.set_password(user_data['password'])  # 使用Django内置的set_password方法
            user.save()
            
            # 创建学生信息
            try:
                # 尝试获取班级ID，如果没有提供则使用默认值
                clazz_id = request.data.get('clazz_id', 1)
                student = Student(
                    user=user, 
                    name=request.data.get('name', username),
                    clazz_id=clazz_id
                )
                student.save()
                
                return Response({
                    'msg': '注册成功', 
                    'status': 'success'
                }, status=status.HTTP_201_CREATED)
            except Exception as e:
                # 如果学生创建失败，删除用户以保持数据一致性
                user.delete()
                return Response({
                    'msg': '学生信息创建失败: {}'.format(str(e)), 
                    'status': 'error'
                }, status=status.HTTP_200_OK)
        else:
            return Response({
                'msg': '表单验证失败', 
                'errors': user_detail.errors,
                'status': 'error'
            }, status=status.HTTP_200_OK)


class UpdatePwdApi(APIView):
    """
    修改用户密码
    """

    def patch(self, request):
        # 获取参数
        old_pwd = request.data['oldpwd']
        new_pwd = request.data['newpwd']
        user_id = request.data['userid']
        # 获得请求用户
        user = User.objects.get(id=user_id)
        # 检查原始密码是否正确
        if user.check_password(old_pwd):
            user.set_password(new_pwd)
            user.save()
        else:
            return Response(data={'msg': 'fail'}, status=status.HTTP_200_OK)
        # 返回数据
        return Response(data={'msg': 'success'}, status=status.HTTP_200_OK)


class StudentViewSet(viewsets.ModelViewSet):
    """
    学生信息
    """
    # 查询集
    queryset = Student.objects.all().order_by('id')
    # 序列化
    serializer_class = StudentSerializer


class ClazzListViewSet(viewsets.ModelViewSet):
    """
    班级信息
    """
    # 查询集
    queryset = Clazz.objects.all().order_by('id')
    # 序列化
    serializer_class = ClazzSerializer
