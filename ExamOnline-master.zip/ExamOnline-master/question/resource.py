from import_export import resources
from import_export.fields import Field
from import_export.widgets import CharWidget

from question.models import Choice, Fill, Judge, Program


class LevelWidget(CharWidget):
    """自定义难度等级转换器，将中文难度转换为单字符代码"""
    # 定义难度映射关系
    LEVEL_MAP = {
        '入门': '1',
        '简单': '2',
        '普通': '3',
        '较难': '4',
        '困难': '5',
        # 也支持直接使用单字符值
        '1': '1',
        '2': '2',
        '3': '3',
        '4': '4',
        '5': '5'
    }
    
    def clean(self, value, row=None, *args, **kwargs):
        """导入时，将Excel中的难度值转换为单字符代码"""
        if value:
            # 去除首尾空格
            value = value.strip()
            # 尝试转换，如找不到对应映射则默认返回'1'（入门）
            return self.LEVEL_MAP.get(value, '1')
        return '1'  # 默认值


class JudgeAnswerWidget(CharWidget):
    """自定义判断题答案转换器，将中文答案转换为单字符代码"""
    # 定义答案映射关系
    ANSWER_MAP = {
        '正确': 'T',
        '对': 'T',
        '是': 'T',
        '错误': 'F',
        '错': 'F',
        '否': 'F',
        # 也支持直接使用单字符值
        'T': 'T',
        'F': 'F',
        't': 'T',
        'f': 'F'
    }
    
    def clean(self, value, row=None, *args, **kwargs):
        """导入时，将Excel中的答案值转换为单字符代码"""
        if value:
            # 去除首尾空格
            value = value.strip()
            # 尝试转换，如找不到对应映射则默认返回'T'
            return self.ANSWER_MAP.get(value, 'T')
        return 'T'  # 默认值


class ChoiceResource(resources.ModelResource):
    # 使用自定义widget处理level字段
    level = Field(attribute='level', widget=LevelWidget())
    
    class Meta:
        model = Choice
        fields = ('id', 'question', 'answer_A', 'answer_B', 'answer_C', 'answer_D', 'right_answer', 'analysis', 'score', 'level')


class FillResource(resources.ModelResource):
    # 使用自定义widget处理level字段
    level = Field(attribute='level', widget=LevelWidget())
    
    class Meta:
        model = Fill
        fields = ('id', 'question', 'right_answer', 'analysis', 'score', 'level')


class JudgeResource(resources.ModelResource):
    # 使用自定义widget处理level字段
    level = Field(attribute='level', widget=LevelWidget())
    # 使用自定义widget处理right_answer字段
    right_answer = Field(attribute='right_answer', widget=JudgeAnswerWidget())
    
    class Meta:
        model = Judge
        fields = ('id', 'question', 'right_answer', 'analysis', 'score', 'level')


class LanguageWidget(CharWidget):
    """自定义编程语言转换器，将中文语言名称转换为代码"""
    # 定义语言映射关系
    LANGUAGE_MAP = {
        'Python': 'python',
        'Python3': 'python',
        'Python2': 'python',
        'python': 'python',
        'Java': 'java',
        'java': 'java',
        'C': 'c',
        'c': 'c',
        'C++': 'cpp',
        'c++': 'cpp',
        'CPP': 'cpp',
        'cpp': 'cpp'
    }
    
    def clean(self, value, row=None, *args, **kwargs):
        """导入时，将Excel中的语言值转换为代码"""
        if value:
            # 去除首尾空格
            value = value.strip()
            # 尝试转换，如找不到对应映射则默认返回'python'
            return self.LANGUAGE_MAP.get(value, 'python')
        return 'python'  # 默认值


class ProgramResource(resources.ModelResource):
    # 使用自定义widget处理level字段
    level = Field(attribute='level', widget=LevelWidget())
    # 使用自定义widget处理language字段
    language = Field(attribute='language', widget=LanguageWidget())
    
    class Meta:
        model = Program
        fields = ('id', 'question', 'language', 'answer_template', 'test_case', 'expected_output', 'analysis', 'score', 'level')
        # 如果导入的Excel中没有包含某些字段，可以设置排除
        # exclude = ('created_at', 'updated_at', 'time_limit', 'memory_limit')