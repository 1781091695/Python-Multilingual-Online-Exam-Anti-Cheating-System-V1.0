import subprocess

from rest_framework import mixins, viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from question.models import Choice, Fill, Judge, Program
from question.serializers import ChoiceSerializer, FillSerializer, JudgeSerializer, ProgramSerializer


# Create your views here.


class ChoiceListViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """选择题列表页"""
    # 这里要定义一个默认的排序，否则会报错
    queryset = Choice.objects.all().order_by('id')[:0]
    # 序列化
    serializer_class = ChoiceSerializer

    # 重写queryset
    def get_queryset(self):
        # 题目数量
        choice_number = int(self.request.query_params.get("choice_number"))
        level = int(self.request.query_params.get("level", 1))

        if choice_number:
            self.queryset = Choice.objects.all().filter(level=level).order_by('?')[:choice_number]
        return self.queryset


class FillListViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """填空题列表页"""
    # 这里要定义一个默认的排序，否则会报错
    queryset = Fill.objects.all().order_by('id')[:0]
    # 序列化
    serializer_class = FillSerializer

    # 重写queryset
    def get_queryset(self):
        # 题目数量
        fill_number = int(self.request.query_params.get("fill_number"))
        level = int(self.request.query_params.get("level", 1))

        if fill_number:
            self.queryset = Fill.objects.all().filter(level=level).order_by('?')[:fill_number]
        return self.queryset


class JudgeListViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """判断题列表页"""
    # 这里要定义一个默认的排序，否则会报错
    queryset = Judge.objects.all().order_by('?')[:0]
    # 序列化
    serializer_class = JudgeSerializer

    # 重写queryset
    def get_queryset(self):
        # 题目数量
        judge_number = int(self.request.query_params.get("judge_number"))
        level = int(self.request.query_params.get("level", 1))

        if judge_number:
            self.queryset = Judge.objects.all().filter(level=level).order_by('?')[:judge_number]
        return self.queryset


class ProgramListViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """编程题列表页"""
    # 这里定义一个默认的排序，否则会报错
    queryset = Program.objects.all().order_by('?')[:0]
    # 序列化
    serializer_class = ProgramSerializer

    # 重写queryset
    def get_queryset(self):
        # 题目数量
        program_number = int(self.request.query_params.get("program_number"))
        level = int(self.request.query_params.get("level", 1))

        if program_number:
            self.queryset = Program.objects.all().filter(level=level).order_by('?')[:program_number]
        return self.queryset


import os
import uuid
import tempfile
import shutil
from datetime import datetime

class CheckProgramApi(APIView):
    """编程题评测接口"""

    def post(self, request):
        # 获取提交的数据
        json_body = request.data
        
        # 验证必要参数
        if 'answer' not in json_body or 'program_id' not in json_body:
            return Response({'status': 'error', 'message': '缺少必要参数'})
        
        try:
            # 获取编程题信息
            program = Program.objects.get(id=json_body['program_id'])
            
            # 创建临时目录用于安全执行代码
            temp_dir = tempfile.mkdtemp()
            
            # 根据编程语言处理执行逻辑
            if program.language == 'python':
                result = self._execute_python_code(
                    program=program,
                    user_answer=json_body['answer'],
                    temp_dir=temp_dir
                )
            elif program.language in ['java', 'c', 'cpp']:
                # 这里可以扩展支持其他语言
                return Response({'status': 'error', 'message': f'暂不支持{program.get_language_display()}语言'})
            else:
                return Response({'status': 'error', 'message': '不支持的编程语言'})
                
            return Response(result)
            
        except Program.DoesNotExist:
            return Response({'status': 'error', 'message': '编程题不存在'})
        except Exception as e:
            return Response({'status': 'error', 'message': f'评测过程中发生错误: {str(e)}'})
        finally:
            # 清理临时文件
            if 'temp_dir' in locals() and os.path.exists(temp_dir):
                shutil.rmtree(temp_dir)
    
    def _execute_python_code(self, program, user_answer, temp_dir):
        """安全执行Python代码并评测"""
        # 生成唯一的文件名
        file_name = f"solution_{uuid.uuid4().hex}.py"
        file_path = os.path.join(temp_dir, file_name)
        
        # 写入用户代码
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(user_answer)
        
        # 准备执行命令
        cmd = ['python', file_path]
        
        try:
            # 执行代码，设置超时时间（毫秒转换为秒）
            start_time = datetime.now()
            process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                cwd=temp_dir,
                timeout=program.time_limit / 1000.0  # 转换为秒
            )
            
            # 输入测试用例
            stdout, stderr = process.communicate(input=program.test_case)
            
            # 计算执行时间
            execution_time = (datetime.now() - start_time).total_seconds() * 1000  # 毫秒
            
            # 检查执行结果
            if process.returncode != 0:
                return {
                    'status': 'error',
                    'message': '代码执行出错',
                    'error': stderr.strip(),
                    'execution_time': execution_time
                }
            
            # 验证输出
            user_output = stdout.strip()
            expected_output = program.expected_output.strip()
            
            # 基本的输出对比（可以根据需要调整更复杂的比较逻辑）
            if user_output == expected_output:
                return {
                    'status': 'success',
                    'message': '通过',
                    'execution_time': execution_time,
                    'score': program.score
                }
            else:
                return {
                    'status': 'fail',
                    'message': '输出结果不匹配',
                    'expected': expected_output,
                    'received': user_output,
                    'execution_time': execution_time
                }
                
        except subprocess.TimeoutExpired:
            process.kill()
            return {
                'status': 'error',
                'message': f'代码执行超时（超过{program.time_limit}毫秒）'
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': f'执行过程中发生错误: {str(e)}'
            }
