from rest_framework import serializers
from .models import Choice, Fill, Judge, Program


class ChoiceSerializer(serializers.ModelSerializer):
    class Meta:
        model = Choice
        fields = '__all__'


class FillSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fill
        fields = '__all__'


class JudgeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Judge
        fields = '__all__'


class ProgramSerializer(serializers.ModelSerializer):
    # 添加可读的字段展示
    language_display = serializers.CharField(source='get_language_display', read_only=True)
    
    class Meta:
        model = Program
        fields = ['id', 'question', 'language', 'language_display', 'answer_template', 
                 'test_case', 'expected_output', 'analysis', 'score', 'level', 
                 'time_limit', 'memory_limit', 'created_at', 'updated_at']
        
        # 设置只读字段
        read_only_fields = ['created_at', 'updated_at']
    
    def validate(self, data):
        # 自定义验证逻辑
        if data.get('time_limit') and data['time_limit'] < 100:
            raise serializers.ValidationError("时间限制不能小于100毫秒")
            
        if data.get('memory_limit') and data['memory_limit'] < 1:
            raise serializers.ValidationError("内存限制不能小于1MB")
            
        if data.get('score') and data['score'] <= 0:
            raise serializers.ValidationError("分数必须大于0")
            
        return data
